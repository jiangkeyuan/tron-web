const s="/assets/api-create.18db20c5.png";export{s as _};
//# sourceMappingURL=api-create.a82a0d55.js.map
