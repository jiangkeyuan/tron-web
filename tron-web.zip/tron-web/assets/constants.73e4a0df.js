function n(t){return t==null}class o extends Error{constructor(e){super(e),this.name="ElementPlusError"}}function r(t,e){throw new o(`[${t}] ${e}`)}function s(t,e){}const a="update:modelValue",E="change",c="input",m=Symbol("formContextKey"),u=Symbol("formItemContextKey");export{E as C,c as I,a as U,m as a,s as d,u as f,n as i,r as t};
//# sourceMappingURL=constants.73e4a0df.js.map
