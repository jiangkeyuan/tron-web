import{_ as t}from"./_plugin-vue_export-helper.cdc0426e.js";import{e as s,h as o,a1 as n,k as _}from"./index.e46ffe7a.js";const c={},a={class:"page"},d={class:"page-content"};function r(e,f){return s(),o("div",a,[n("div",d,[_(e.$slots,"default",{},void 0,!0)])])}const p=t(c,[["render",r],["__scopeId","data-v-87d0b3f6"]]);export{p as C};
//# sourceMappingURL=content.5f37d65d.js.map
