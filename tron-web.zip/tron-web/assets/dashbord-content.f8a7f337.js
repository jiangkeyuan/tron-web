import{_}from"./_plugin-vue_export-helper.cdc0426e.js";import{e as n,h as o,k as t}from"./index.cc0673c3.js";const s={},c={class:"dashbord-content"};function r(e,d){return n(),o("div",c,[t(e.$slots,"default",{},void 0,!0)])}const p=_(s,[["render",r],["__scopeId","data-v-2576811c"]]);export{p as _};
//# sourceMappingURL=dashbord-content.f8a7f337.js.map
