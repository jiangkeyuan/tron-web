const s="/assets/doc-s1.78bc5b39.svg";export{s as _};
//# sourceMappingURL=doc-s1.a5e4b1bf.js.map
