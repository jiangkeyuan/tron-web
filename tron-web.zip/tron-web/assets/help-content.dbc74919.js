import{_ as t}from"./_plugin-vue_export-helper.cdc0426e.js";import{e as n,h as o,k as _}from"./index.cc0673c3.js";const s={},c={class:"help-content"};function r(e,d){return n(),o("div",c,[_(e.$slots,"default",{},void 0,!0)])}const p=t(s,[["render",r],["__scopeId","data-v-3d941c3f"]]);export{p as H};
//# sourceMappingURL=help-content.dbc74919.js.map
