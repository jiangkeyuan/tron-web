import{_ as c}from"./_plugin-vue_export-helper.cdc0426e.js";const r={};function e(n,t){return null}const o=c(r,[["render",e]]);export{o as default};
//# sourceMappingURL=ic.cf2162df.js.map
