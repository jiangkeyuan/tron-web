import{H as e}from"./page.230dff54.js";import{e as o,f as r}from"./index.cc0673c3.js";import"./_plugin-vue_export-helper.cdc0426e.js";const m={__name:"index",setup(t){return(a,c)=>(o(),r(e))}};export{m as default};
//# sourceMappingURL=index.3e8732b0.js.map
