import{_ as e}from"./dashbord-content.22e07351.js";import{H as t}from"./help-items.a12f6ce4.js";import{e as o,f as r,w as a,l as _}from"./index.58f0b083.js";import"./_plugin-vue_export-helper.cdc0426e.js";import"./doc-s1.a5e4b1bf.js";const f={__name:"index",setup(p){return(s,m)=>(o(),r(e,null,{default:a(()=>[_(t)]),_:1}))}};export{f as default};
//# sourceMappingURL=index.6773be05.js.map
