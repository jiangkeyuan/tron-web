import{aJ as a,c,g as o,Q as r,D as i}from"./index.58f0b083.js";const n={prefix:Math.floor(Math.random()*1e4),current:0},u=Symbol("elIdInjection"),d=()=>r()?i(u,n):n,m=t=>{const e=d(),s=a();return c(()=>o(t)||`${s.value}-id-${e.prefix}-${e.current++}`)};export{d as a,m as u};
//# sourceMappingURL=index.70004aaf.js.map
