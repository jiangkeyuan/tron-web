import{_ as e}from"./dashbord-content.726c4c82.js";import{H as t}from"./help-items.d7a55f7c.js";import{e as o,f as r,w as a,l as _}from"./index.e46ffe7a.js";import"./_plugin-vue_export-helper.cdc0426e.js";import"./doc-s1.a5e4b1bf.js";const f={__name:"index",setup(p){return(s,m)=>(o(),r(e,null,{default:a(()=>[_(t)]),_:1}))}};export{f as default};
//# sourceMappingURL=index.bf551273.js.map
