import{c0 as s}from"./index.e46ffe7a.js";const l=async()=>await s.get("/seller/user/latest/sells"),r=async()=>await s.get("/seller/user/almost/sells"),a=async e=>await s({url:"/seller/user/sells",method:"post",data:e});export{r as a,a as b,l as g};
//# sourceMappingURL=index.ddf862be.js.map
