import{H as e}from"./page.9a22a1c7.js";import{e as o,f as r}from"./index.58f0b083.js";import"./_plugin-vue_export-helper.cdc0426e.js";const m={__name:"index",setup(t){return(a,c)=>(o(),r(e))}};export{m as default};
//# sourceMappingURL=index.e7433837.js.map
