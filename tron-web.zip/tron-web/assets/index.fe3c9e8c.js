import{_ as e}from"./dashbord-content.f8a7f337.js";import{H as t}from"./help-items.9a59ff75.js";import{e as o,f as r,w as a,l as _}from"./index.cc0673c3.js";import"./_plugin-vue_export-helper.cdc0426e.js";import"./doc-s1.a5e4b1bf.js";const f={__name:"index",setup(p){return(s,m)=>(o(),r(e,null,{default:a(()=>[_(t)]),_:1}))}};export{f as default};
//# sourceMappingURL=index.fe3c9e8c.js.map
