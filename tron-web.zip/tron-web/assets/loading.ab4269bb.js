import{bk as c}from"./index.cc0673c3.js";function s(o){const e={lock:!0,text:"\u67E5\u8BE2\u4E2D",target:document.querySelector(".el-table__empty-block")},n=Object.assign(e,o),t=c.service(n);return setTimeout(()=>{t.close()},3e3),t}const r=(o,e={})=>async(...n)=>{const t=s(e),a=await o(...n);return t.close(),a};export{r as a};
//# sourceMappingURL=loading.ab4269bb.js.map
