const s="/assets/logo.00834483.svg";export{s as _};
//# sourceMappingURL=logo.ecf53c3c.js.map
