import{bO as a}from"./index.e46ffe7a.js";const p=(e="")=>e.replace(/[|\\{}()[\]^$+*?.]/g,"\\$&").replace(/-/g,"\\x2d"),t=e=>a(e);export{t as c,p as e};
//# sourceMappingURL=strings.20d5ec64.js.map
