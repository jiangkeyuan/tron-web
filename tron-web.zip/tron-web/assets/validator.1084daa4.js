import{bK as i}from"./index.cc0673c3.js";const n=o=>["",...i].includes(o);export{n as i};
//# sourceMappingURL=validator.1084daa4.js.map
