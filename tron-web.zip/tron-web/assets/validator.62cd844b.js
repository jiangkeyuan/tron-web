import{bI as i}from"./index.e46ffe7a.js";const n=o=>["",...i].includes(o);export{n as i};
//# sourceMappingURL=validator.62cd844b.js.map
