import{bK as i}from"./index.58f0b083.js";const n=o=>["",...i].includes(o);export{n as i};
//# sourceMappingURL=validator.a1c080cc.js.map
